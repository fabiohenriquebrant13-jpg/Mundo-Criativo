/* Compatibilidade ampliada para Safari/iPhone: sem optional chaining,
       arrow functions, spread ou template literals. */
    var CONFIG = {
      whatsappNumber: '5531989630087',
      defaultMessage: 'Olá! Vim pelo site da Mundo Criativo e gostaria de saber mais sobre os produtos da loja.'
    };

    function qs(selector, root) {
      return (root || document).querySelector(selector);
    }
    function qsa(selector, root) {
      return (root || document).querySelectorAll(selector);
    }
    function forEachNode(list, callback) {
      for (var i = 0; i < list.length; i++) callback(list[i], i);
    }

    var toast = qs('#toast');

    function showToast(message) {
      if (!toast) return;
      toast.textContent = message;
      toast.classList.add('show');
      clearTimeout(window.__mcToastTimer);
      window.__mcToastTimer = setTimeout(function () {
        toast.classList.remove('show');
      }, 3000);
    }

    function waUrl(message) {
      var msg = message || CONFIG.defaultMessage;
      return 'https://wa.me/' + CONFIG.whatsappNumber + '?text=' + encodeURIComponent(msg);
    }

    function applyWhatsAppLinks() {
      forEachNode(qsa('.whatsapp-link'), function (link) {
        var msg = link.getAttribute('data-message') || CONFIG.defaultMessage;
        link.setAttribute('href', waUrl(msg));
        link.setAttribute('target', '_blank');
        link.setAttribute('rel', 'noopener');
      });
    }

    applyWhatsAppLinks();

    forEachNode(qsa('.whatsapp-link'), function (link) {
      link.addEventListener('click', function () {
        showToast('Abrindo o WhatsApp com a mensagem pronta.');
      }, false);
    });

    var menuBtn = qs('#menuBtn');
    var navLinks = qs('#navLinks');
    function setMenu(open, moveFocus) {
      if (!menuBtn || !navLinks) return;
      navLinks.classList.toggle('open', open);
      menuBtn.setAttribute('aria-expanded', String(open));
      menuBtn.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
      if (moveFocus) {
        var target = open ? navLinks.querySelector('a') : menuBtn;
        if (target) target.focus();
      }
    }
    if (menuBtn && navLinks) {
      menuBtn.addEventListener('click', function () {
        setMenu(!navLinks.classList.contains('open'), true);
      });
      document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && navLinks.classList.contains('open')) {
          event.preventDefault();
          setMenu(false, true);
        }
      });
      document.addEventListener('click', function (event) {
        if (navLinks.classList.contains('open') && !navLinks.contains(event.target) && !menuBtn.contains(event.target)) setMenu(false, false);
      });
      navLinks.addEventListener('keydown', function (event) {
        var links = navLinks.querySelectorAll('a');
        if (event.key === 'Tab' && event.shiftKey && document.activeElement === links[0]) {
          event.preventDefault(); setMenu(false, true);
        } else if (event.key === 'Tab' && !event.shiftKey && document.activeElement === links[links.length - 1]) {
          event.preventDefault(); setMenu(false, true);
        }
      });
      window.matchMedia('(max-width: 768px)').addEventListener('change', function () { setMenu(false, false); });
    }
    forEachNode(qsa('#navLinks a'), function (link) {
      link.addEventListener('click', function () { setMenu(false, false); });
    });
    var reviewsRegion = qs('.reviews-carousel');
    if (reviewsRegion) reviewsRegion.addEventListener('keydown', function (event) {
      if (event.target !== reviewsRegion) return;
      if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
        event.preventDefault();
        reviewsRegion.scrollBy({left: (event.key === 'ArrowRight' ? 1 : -1) * reviewsRegion.clientWidth * 0.9, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'});
      }
    });

    var bullets = {
      'Roupas': [
        'Opções para diferentes estilos e momentos.',
        'Atendimento personalizado para ajudar na escolha.',
        'Consulte novidades diretamente pelo WhatsApp.'
      ],
      'Eletrônicos': [
        'Acessórios e itens para facilitar sua rotina.',
        'Consulte disponibilidade e novidades com a equipe.',
        'Atendimento rápido pelo WhatsApp.'
      ],
      'Papelaria': [
        'Materiais para estudar, organizar, criar e presentear.',
        'Cadernos, canetas, lápis e muito mais.',
        'Fale com a equipe para encontrar o que procura.'
      ],
      'Promoções': [
        'Confira oportunidades e ofertas disponíveis.',
        'Pergunte sobre as promoções atuais da loja.',
        'Aproveite enquanto houver disponibilidade.'
      ],
      'Brinquedos': [
        'Presentes e diversão para diferentes idades.',
        'Opções para estimular criatividade e imaginação.',
        'Peça sugestões diretamente à nossa equipe.'
      ],
      'Avaliações': [
        'Sua opinião ajuda nossa loja a melhorar todos os dias.',
        'Conheça nossa seção de avaliações.',
        'Você também pode avaliar a Mundo Criativo no Google.'
      ]
    };

    var selection = qs('#selection');
    var selectionTitle = qs('#selTitle');
    var selectionText = qs('#selText');
    var selectionIcon = qs('#selIcon');
    var selectionList = qs('#selList');
    var selectionWhatsapp = qs('#selectionWhatsapp');

    function scrollToSelection() {
      if (!selection) return;
      setTimeout(function () {
        try {
          selection.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } catch (e) {
          selection.scrollIntoView(true);
        }
      }, 80);
    }

    forEachNode(qsa('.cat'), function (card) {
      card.addEventListener('click', function () {
        forEachNode(qsa('.cat'), function (c) { c.classList.remove('active'); });
        card.classList.add('active');

        var category = card.getAttribute('data-category') || '';
        var message = card.getAttribute('data-message') || CONFIG.defaultMessage;
        var color = card.getAttribute('data-color') || '#ff5b5b';
        var icon = card.getAttribute('data-icon') || '';
        var text = card.getAttribute('data-text') || '';

        if (selection) selection.style.setProperty('--sel', color);
        if (selectionTitle) selectionTitle.textContent = category;
        if (selectionText) selectionText.textContent = text;
        if (selectionIcon && icon) {
          selectionIcon.src = icon;
          selectionIcon.alt = 'Ícone ' + category;
          selectionIcon.classList.remove('icon-jump');
          void selectionIcon.offsetWidth;
          selectionIcon.classList.add('icon-jump');
        }
        if (selectionWhatsapp) {
          selectionWhatsapp.setAttribute('data-message', message);
          selectionWhatsapp.setAttribute('href', waUrl(message));
        }
        if (selectionList) {
          var items = bullets[category] || [];
          var html = '';
          for (var i = 0; i < items.length; i++) html += '<li>' + items[i] + '</li>';
          selectionList.innerHTML = html;
        }

        scrollToSelection();
      }, false);
    });


    function setupCategoryMarquee() {
      var wrap = qs('.strip-wrap');
      if (!wrap) return;
      var items = qsa('.strip-item', wrap);
      if (!items || items.length === 0) return;

      forEachNode(items, function (item) {
        var label = qs('span', item);
        if (label && !item.getAttribute('data-category')) {
          item.setAttribute('data-category', label.textContent.replace(/^\s+|\s+$/g, ''));
        }
      });

      var original = wrap.innerHTML;
      var track = document.createElement('div');
      var setOne = document.createElement('div');
      var setTwo = document.createElement('div');

      track.className = 'strip-track';
      setOne.className = 'strip-set';
      setTwo.className = 'strip-set';
      setTwo.setAttribute('aria-hidden', 'true');
      setOne.innerHTML = original;
      setTwo.innerHTML = original;
      track.appendChild(setOne);
      track.appendChild(setTwo);

      wrap.innerHTML = '';
      wrap.appendChild(track);
      if (wrap.className.indexOf('marquee-ready') === -1) wrap.className += ' marquee-ready';

      var clickable = qsa('.strip-item', track);
      forEachNode(clickable, function (item) {
        item.addEventListener('click', function () {
          var category = item.getAttribute('data-category') || '';
          var cards = qsa('.cat');
          forEachNode(cards, function (card) {
            if ((card.getAttribute('data-category') || '') === category) {
              try { card.click(); } catch (e) {}
            }
          });
        }, false);
      });

      /* Pausa somente enquanto o usuário interage com a faixa. */
      wrap.addEventListener('pointerdown', function () {
        track.style.animationPlayState = 'paused';
      }, false);
      wrap.addEventListener('pointerup', function () {
        track.style.animationPlayState = 'running';
      }, false);
      wrap.addEventListener('pointercancel', function () {
        track.style.animationPlayState = 'running';
      }, false);
    }

    setupCategoryMarquee();

    /* Animação é opcional. Se o iPhone não suportar IntersectionObserver,
       todo o conteúdo continua visível normalmente. */
    if ('IntersectionObserver' in window) {
      document.documentElement.classList.add('motion-ready');
      var io = new IntersectionObserver(function (entries) {
        for (var i = 0; i < entries.length; i++) {
          if (entries[i].isIntersecting) entries[i].target.classList.add('visible');
        }
      }, { threshold: 0.14 });
      forEachNode(qsa('.reveal'), function (el) { io.observe(el); });
    }
  